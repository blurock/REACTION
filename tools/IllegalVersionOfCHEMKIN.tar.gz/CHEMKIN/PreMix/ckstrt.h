
C
C     include file for cklib.f
C
      COMMON /CKSTRT/ NMM , NKK , NII , MXSP, MXTB, MXTP, NCP , NCP1,
     1                NCP2, NCP2T,NPAR, NLAR, NFAR, NLAN, NFAL, NREV,
     2                NTHB, NRLT, NWL,  NEIM, NJAN, NJAR, NFT1, NF1R,
     3                NEXC, NRNU, NORD, MXORD,
     4                IcMM, IcKK, IcNC, IcPH, IcCH, IcNT, IcNU, IcNK, 
     5                IcNS, IcNR, IcLT, IcRL, IcRV, IcWL, IcFL, IcFO, 
     6                IcKF, IcTB, IcKN, IcKT, IcEI, IcTD, IcJN, IcF1, 
     7                IcEX, IcRNU,IcORD,IcKOR,
     8                NcAW, NcWT, NcTT, NcAA, NcCO, NcRV, NcLT, NcRL, 
     9                NcFL, NcKT, NcWL, NcJN, NcF1, NcEX, NcRU, NcRC, 
     *                NcPA, NcKF, NcKR, NcRNU,NcKOR,NcK1, NcK2, NcK3, 
     +                NcK4, NcI1, NcI2, NcI3, NcI4
C
C     END include file for cklib.f
C
